#include <bits/stdc++.h>
using namespace std;
int main()
{
    //freopen("1.in","r",stdin);
    //freopen("1.out","w",stdout);
}
